package com.example.BookStoreAPI.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.BookStoreAPI.model.Book;

@RestController
@RequestMapping("/books")
public class BookController {

	private List<Book> books = new ArrayList<>();

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-API-VERSION", "1.0");  // Adding a custom header
        return ResponseEntity.ok().headers(headers).body(books);
    }

    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        books.add(book);
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Operation", "Book Created");  // Adding a custom header
        return ResponseEntity.status(HttpStatus.CREATED).headers(headers).body(book);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book bookDetails) {
        Book book = books.stream().filter(b -> id.equals(b.getId())).findFirst().orElse(null);
        if (book == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        book.setTitle(bookDetails.getTitle());
        book.setAuthor(bookDetails.getAuthor());
        book.setPrice(bookDetails.getPrice());
        book.setIsbn(bookDetails.getIsbn());
        
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Operation", "Book Updated");  // Adding a custom header
        return ResponseEntity.ok().headers(headers).body(book);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        books.removeIf(book -> id.equals(book.getId()));
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Operation", "Book Deleted");  // Adding a custom header
        return ResponseEntity.noContent().headers(headers).build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = books.stream().filter(b -> id.equals(b.getId())).findFirst().orElse(null);
        if (book == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Operation", "Book Found");  // Adding a custom header
        return ResponseEntity.ok().headers(headers).body(book);
    }
}
