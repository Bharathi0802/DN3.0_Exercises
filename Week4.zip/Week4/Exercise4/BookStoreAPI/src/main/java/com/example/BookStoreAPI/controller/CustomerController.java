package com.example.BookStoreAPI.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookStoreAPI.model.Customer;

@RestController
@RequestMapping("/customers")
public class CustomerController {

	private List<Customer> customers = new ArrayList<>();

	 @PostMapping("/register")
	    public ResponseEntity<Customer> registerCustomer(@RequestParam("name") String name,
	                                                     @RequestParam("email") String email,
	                                                     @RequestParam("address") String address) {
	        Customer customer = new Customer();
	        customer.setName(name);
	        customer.setEmail(email);
	        customer.setAddress(address);
	        
	        customers.add(customer);
	        return ResponseEntity.ok(customer);
	    }
}
