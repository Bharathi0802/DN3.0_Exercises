package com.example.EmployeeManagement.repo;

import com.example.EmployeeManagement.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface EmployeeRepo extends JpaRepository<Employee, Long> {

	Page<Employee> findByDepartmentId(Long departmentId, Pageable pageable);
}
