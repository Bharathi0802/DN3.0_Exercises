package com.example.EmployeeManagement.controller;

import com.example.EmployeeManagement.model.Department;
import com.example.EmployeeManagement.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/departments")
public class DepartmentController {

	 @Autowired
	    private DepartmentService departmentService;

	    // Create a new department
	    @PostMapping
	    public ResponseEntity<Department> createDepartment(@RequestBody Department department) {
	        Department createdDepartment = departmentService.saveDepartment(department);
	        return ResponseEntity.ok(createdDepartment);
	    }

	    // Get all departments
	    @GetMapping
	    public ResponseEntity<List<Department>> getAllDepartments() {
	        List<Department> departments = departmentService.getAllDepartments();
	        return ResponseEntity.ok(departments);
	    }

	    // Get a department by ID
	    @GetMapping("/{id}")
	    public ResponseEntity<Department> getDepartmentById(@PathVariable Long id) {
	        Optional<Department> department = departmentService.getDepartmentById(id);
	        return department.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	    }

	    // Update a department
	    @PutMapping("/{id}")
	    public ResponseEntity<Department> updateDepartment(@PathVariable Long id, @RequestBody Department department) {
	        Department updatedDepartment = departmentService.updateDepartment(id, department);
	        return ResponseEntity.ok(updatedDepartment);
	    }

	    // Delete a department
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteDepartment(@PathVariable Long id) {
	        departmentService.deleteDepartment(id);
	        return ResponseEntity.noContent().build();
	    }
}
