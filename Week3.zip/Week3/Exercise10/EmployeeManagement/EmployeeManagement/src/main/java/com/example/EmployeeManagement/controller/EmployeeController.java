package com.example.EmployeeManagement.controller;

import com.example.EmployeeManagement.model.Employee;
import com.example.EmployeeManagement.repo.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/employees")

public class EmployeeController {

	@Autowired
    private EmployeeRepo employeeRepository;

    @GetMapping
    public ResponseEntity<Page<Employee>> getEmployees(
            @RequestParam Optional<Long> departmentId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.fromString(sortDir), sortBy));

        Page<Employee> employees;
        if (departmentId.isPresent()) {
            employees = employeeRepository.findByDepartmentId(departmentId.get(), pageable);
        } else {
            employees = employeeRepository.findAll(pageable);
        }

        return ResponseEntity.ok(employees);
    }
}
