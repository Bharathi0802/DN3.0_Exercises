package com.example.EmployeeManagement.projection;

import org.springframework.beans.factory.annotation.Value;

public interface EmployeeProjection {

	@Value("#{target.id} as id")
    Long getId();

    @Value("#{target.name} as name")
    String getName();

    @Value("#{target.email} as email")
    String getEmail();

    @Value("#{target.department.name} as departmentName") // Assuming Department entity has a name field
    String getDepartmentName();
}
