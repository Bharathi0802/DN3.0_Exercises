package com.example.EmployeeManagement.repo;

import com.example.EmployeeManagement.dto.EmployeeDTO;
import com.example.EmployeeManagement.projection.EmployeeProjection;
import com.example.EmployeeManagement.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface EmployeeRepo extends JpaRepository<Employee, Long> {

	
	Page<Employee> findByDepartmentId(Long departmentId, Pageable pageable);
	
	//interface based projection
	@Query("SELECT e.id AS id, e.name AS name, e.email AS email, d.name AS departmentName " +
	           "FROM Employee e JOIN e.department d")
	    Page<EmployeeProjection> findEmployeeProjections(Pageable pageable);
	
	//class based projections
	@Query("SELECT new com.example.employeemanagementsystem.dto.EmployeeDTO(e.id, e.name, e.email, d.name) " +
	           "FROM Employee e JOIN e.department d")
	    Page<EmployeeDTO> findEmployeeDTOs(Pageable pageable);
}
