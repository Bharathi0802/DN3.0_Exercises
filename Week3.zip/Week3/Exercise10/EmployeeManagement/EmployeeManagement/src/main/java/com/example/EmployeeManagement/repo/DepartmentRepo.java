package com.example.EmployeeManagement.repo;

import com.example.EmployeeManagement.dto.DepartmentDTO;
import com.example.EmployeeManagement.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface DepartmentRepo extends JpaRepository<Department, Long>{

	//custom query
	@Query("SELECT d FROM Department d WHERE d.name LIKE %:keyword%")
    List<Department> findDepartmentsByNameContaining(@Param("keyword") String keyword);
	
	//named query
	 @Query(name = "Department.findByName")
	    List<Department> findByName(@Param("name") String name);
	    
	    //class based projection
	    @Query("SELECT new com.example.employeemanagementsystem.dto.DepartmentDTO(d.id, d.name) " +
	            "FROM Department d")
	     Page<DepartmentDTO> findDepartmentDTOs(Pageable pageable);
}
