package com.example.EmployeeManagement.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.EmployeeManagement.model.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service
public class EmployeeService {

	@PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public void batchInsertEmployees(List<Employee> employees) {
        int batchSize = 50;

        for (int i = 0; i < employees.size(); i++) {
            entityManager.persist(employees.get(i));

            if (i % batchSize == 0 && i > 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }
    }
}
