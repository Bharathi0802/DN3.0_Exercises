package com.example.EmployeeManagement.repo;

import com.example.EmployeeManagement.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface DepartmentRepo extends JpaRepository<Department, Long>{

	//custom query
	@Query("SELECT d FROM Department d WHERE d.name LIKE %:keyword%")
    List<Department> findDepartmentsByNameContaining(@Param("keyword") String keyword);
	
	//named query
	 @Query(name = "Department.findByName")
	    List<Department> findByName(@Param("name") String name);
}
