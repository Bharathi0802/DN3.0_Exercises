package com.library.service;

import com.library.repo.BookRepository;


public class BookService {

	private BookRepository bookRepository;

	public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public BookService() {
    }

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }
}
