package com.library.repo;

public class BookRepository {

}
