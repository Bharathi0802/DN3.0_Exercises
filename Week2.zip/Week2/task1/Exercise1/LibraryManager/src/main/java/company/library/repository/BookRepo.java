package company.library.repository;

public class BookRepo {

	 @Override
	    public String toString() {
	        return "BookRepository";
	    }
}
