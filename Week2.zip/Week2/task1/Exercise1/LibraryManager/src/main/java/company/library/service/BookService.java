package company.library.service;
import company.library.repository.BookRepo;
public class BookService {

	private BookRepo bookRepository;

    public void setBookRepo(BookRepo bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void printBookService() {
        System.out.println("BookService is working with " + bookRepository);
    }
}
