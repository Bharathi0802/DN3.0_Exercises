package company.library.repository;

public class BookRepo {

	 public void printRepo() {
	        System.out.println("BookRepository is working");
	    }
}
