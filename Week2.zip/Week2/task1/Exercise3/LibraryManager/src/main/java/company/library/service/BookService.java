package company.library.service;
import company.library.repository.BookRepo;
public class BookService {

	private BookRepo bookRepository;

    public void setBookRepo(BookRepo bookRepository) {
        this.bookRepository = bookRepository;
    }
    
    public void service() {
        System.out.println("BookService is working");
        bookRepository.printRepo();
    }
}
