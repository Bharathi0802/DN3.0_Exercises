package com.example.BookStoreAPI.assembler;

import com.example.BookStoreAPI.controller.BookController;
import com.example.BookStoreAPI.dto.BookDTO;
import com.example.BookStoreAPI.model.Book;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.RepresentationModelAssemblerSupport;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Component;

@Component
public class BookResourceAssembler extends RepresentationModelAssemblerSupport<Book, EntityModel<BookDTO>>{

	 public BookResourceAssembler() {
	        super(BookController.class, BookDTO.class);
	    }

	    public EntityModel<BookDTO> toModel(Book book) {
	        BookDTO bookDTO = new BookDTO(book.getId(), book.getTitle(), book.getAuthor(), book.getPrice(), book.getIsbn());
	        EntityModel<BookDTO> bookResource = EntityModel.of(bookDTO);

	        Link selfLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(book.getId())).withSelfRel();
	        Link allBooksLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getAllBooks()).withRel("all-books");

	        bookResource.add(selfLink, allBooksLink);

	        return bookResource;
	    }
}
