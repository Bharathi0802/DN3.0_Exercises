package com.example.BookStoreAPI.dto;
public class CustomerDTO {

	private Long id;

    @NotNull(message = "Name cannot be null")
    @Size(min = 1, max = 100, message = "Name must be between 1 and 100 characters")
    private String name;

    @NotNull(message = "Email cannot be null")
    @Email(message = "Email should be valid")
    private String email;

    @Size(max = 15, message = "Phone number must be up to 15 characters", min = 0)
    private String phoneNumber;
	    
	    public CustomerDTO() { }

	    public CustomerDTO(Long id, String name, String email, String phoneNumber) {
	        this.id = id;
	        this.name = name;
	        this.email = email;
	        this.phoneNumber = phoneNumber;
	    }

	    // Getters and Setters
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getPhoneNumber() {
	        return phoneNumber;
	    }

	    public void setPhoneNumber(String phoneNumber) {
	        this.phoneNumber = phoneNumber;
	    }
}
