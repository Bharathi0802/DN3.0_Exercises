package com.example.BookStoreAPI.dto;

public @interface NotNull {

	String message();

}
