package com.example.BookStoreAPI.dto;

public @interface Email {

	String message();

}
