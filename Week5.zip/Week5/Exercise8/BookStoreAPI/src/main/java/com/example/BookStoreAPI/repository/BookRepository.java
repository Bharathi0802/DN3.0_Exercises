package com.example.BookStoreAPI.repository;

import java.util.List;

import com.example.BookStoreAPI.model.Book;

public class BookRepository {

	public List<Book> findAll() {
		
		return null;
	}

	public Book save(Book book) {
		
		return null;
	}

	public boolean existsById(Long id) {
		
		return false;
	}

	public void deleteById(Long id) {
		
		
	}

	public Book findById(Long id) {
		
		return null;
	}

}
