package com.example.BookStoreAPI.dto;

public @interface Min {

	int value();

	String message();

}
