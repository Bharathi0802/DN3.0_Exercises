package com.example.BookStoreAPI.repository;

import java.util.List;

import com.example.BookStoreAPI.model.Customer;

public class CustomerRepository {

	public List<Customer> findAll() {
		
		return null;
	}

	public Customer save(Customer customer) {
		
		return null;
	}

	public boolean existsById(Long id) {
		
		return false;
	}

	public void deleteById(Long id) {
		
	}

	public Customer findById(Long id) {
		
		return null;
	}

}
