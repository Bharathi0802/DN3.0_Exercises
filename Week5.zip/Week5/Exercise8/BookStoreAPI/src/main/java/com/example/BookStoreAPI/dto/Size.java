package com.example.BookStoreAPI.dto;

public @interface Size {

	int min();

	int max();

	String message();

}
